from typing import List
from fastapi import UploadFile, HTTPException, Form
import asyncio
from models.processadorArquivo import FileProcessorFactory
from settings import Settings
import ollama
import logging

logger = logging.getLogger(__name__)

class FileProcessingController:
    def __init__(self, ollama_client, settings: Settings):
        self.ollama_client = ollama_client
        self.settings = settings
        self.factory = FileProcessorFactory()

    def validate_file(self, filename: str) -> bool:
        return filename.rsplit('.', 1)[-1].lower() in self.settings.allowed_extensions

    def process_file(self, file: UploadFile) -> dict:
        if not self.validate_file(file.filename):
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        file_content = file.file.read()
        extension = file.filename.rsplit('.', 1)[-1].lower()
        processor = self.factory.create_processor(extension, self.ollama_client, self.settings)
        result = processor.process(file_content)
        return {"filename": file.filename, "result": result}

    async def process_file_async(self, file: UploadFile) -> dict:
        if not self.validate_file(file.filename):
            raise HTTPException(status_code=400, detail="Unsupported file type")
        
        file_content = await file.read()
        extension = file.filename.rsplit('.', 1)[-1].lower()
        processor = self.factory.create_processor(extension, self.ollama_client, self.settings)
        result = await asyncio.to_thread(processor.process, file_content)
        return {"filename": file.filename, "result": result}

    def process_multiple_files(self, files: List[UploadFile]) -> List[dict]:
        results = []
        for file in files:
            try:
                result = self.process_file(file)
                results.append(result)
            except Exception as e:
                logger.error(f"Error processing file {file.filename}: {str(e)}")
                results.append({"filename": file.filename, "error": str(e)})
        return results

    async def process_multiple_files_async(self, files: List[UploadFile]) -> List[dict]:
        results = []
        for file in files:
            try:
                result = await self.process_file_async(file)
                results.append(result)
            except Exception as e:
                logger.error(f"Error processing file {file.filename}: {str(e)}")
                results.append({"filename": file.filename, "error": str(e)})
        return results

    def process_text(self, text: str) -> dict:
        print('texto recebido: ',text)
        try:
            response = self.ollama_client.generate(model=self.settings.ollama_model_text, prompt=f"Summarize this text: {text[:1000]}")
            return {"result": response['response']}
        except Exception as e:
            logger.error(f"Error processing text: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Text processing failed: {str(e)}")

    async def process_text_async(self, text: str) -> dict:
        try:
            response = await asyncio.to_thread(
                self.ollama_client.generate,
                model=self.settings.ollama_model_text,
                prompt=f"Summarize this text: {text[:1000]}"
            )
            return {"result": response['response']}
        except Exception as e:
            logger.error(f"Error processing text: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Text processing failed: {str(e)}")

    def process_form_text(self, text: str = Form(...)) -> dict:
        return self.process_text(text)

    async def process_form_text_async(self, text: str = Form(...)) -> dict:
        return await self.process_text_async(text)