from fastapi import FastAPI, File, UploadFile, Depends, Body, Form
from fastapi.responses import JSONResponse
from controllers.controle_do_processador_arquivo import FileProcessingController
from settings import Settings
from typing import List
import ollama
import logging

app = FastAPI(title="Ollama File Processing API")

def get_controller() -> FileProcessingController:
    settings = Settings()
    logging.basicConfig(level=getattr(logging, settings.log_level))
    return FileProcessingController(ollama_client=ollama, settings=settings)

@app.post("/sync/process")
def sync_process_file(file: UploadFile = File(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=controller.process_file(file))

@app.post("/async/process")
async def async_process_file(file: UploadFile = File(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=await controller.process_file_async(file))

@app.post("/sync/process_multiple")
def sync_process_multiple_files(files: List[UploadFile] = File(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content={"results": controller.process_multiple_files(files)})

@app.post("/async/process_multiple")
async def async_process_multiple_files(files: List[UploadFile] = File(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content={"results": await controller.process_multiple_files_async(files)})

@app.post("/sync/process_text")
def sync_process_text(text: str = Body(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=controller.process_text(text))

@app.post("/async/process_text")
async def async_process_text(text: str = Body(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=await controller.process_text_async(text))

@app.post("/sync/process_form_text")
def sync_process_form_text(text: str = Form(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=controller.process_form_text(text))

@app.post("/async/process_form_text")
async def async_process_form_text(text: str = Form(...), controller: FileProcessingController = Depends(get_controller)):
    return JSONResponse(content=await controller.process_form_text_async(text))