from abc import ABC, abstractmethod
import ollama
import base64
import PyPDF2
import csv
import json
import io
import logging
from fastapi import HTTPException
from functools import partial
from settings import Settings

logger = logging.getLogger(__name__)

class FileProcessor(ABC):
    @abstractmethod
    def process(self, file_content: bytes) -> str:
        pass

class ImageProcessor(FileProcessor):
    def __init__(self, ollama_client, model: str):
        self.ollama_client = ollama_client
        self.model = model

    def process(self, file_content: bytes) -> str:
        try:
            base64_image = base64.b64encode(file_content).decode('utf-8')
            response = self.ollama_client.generate(
                model=self.model,
                prompt="Describe this image",
                images=[base64_image]
            )
            return response['response']
        except Exception as e:
            logger.error(f"Error processing image: {str(e)}")
            raise HTTPException(status_code=500, detail=f"Image processing failed: {str(e)}")

class AudioProcessor(FileProcessor):
    def process(self, file_content: bytes) -> str:
        return "Audio processing not implemented. Use appropriate model for transcription."

class PDFProcessor(FileProcessor):
    def __init__(self, ollama_client, model: str):
        self.ollama_client = ollama_client
        self.model = model

    def process(self, file_content: bytes) -> str:
        try:
            pdf_reader = PyPDF2.PdfReader(io.BytesIO(file_content))
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text() or ""
            response = self.ollama_client.generate(model=self.model, prompt=f"Summarize this text: {text[:1000]}")
            return response['response']
        except Exception as e:
            logger.error(f"Error processing PDF: {str(e)}")
            raise HTTPException(status_code=500, detail=f"PDF processing failed: {str(e)}")

class CSVProcessor(FileProcessor):
    def __init__(self, ollama_client, model: str):
        self.ollama_client = ollama_client
        self.model = model

    def process(self, file_content: bytes) -> str:
        try:
            csv_file = io.StringIO(file_content.decode('utf-8'))
            csv_reader = csv.DictReader(csv_file)
            data = [row for row in csv_reader]
            response = self.ollama_client.generate(model=self.model, prompt=f"Summarize this CSV data: {json.dumps(data[:5])}")
            return response['response']
        except Exception as e:
            logger.error(f"Error processing CSV: {str(e)}")
            raise HTTPException(status_code=500, detail=f"CSV processing failed: {str(e)}")

class JSONProcessor(FileProcessor):
    def __init__(self, ollama_client, model: str):
        self.ollama_client = ollama_client
        self.model = model

    def process(self, file_content: bytes) -> str:
        try:
            data = json.loads(file_content)
            response = self.ollama_client.generate(model=self.model, prompt=f"Summarize this JSON data: {json.dumps(data)}")
            return response['response']
        except Exception as e:
            logger.error(f"Error processing JSON: {str(e)}")
            raise HTTPException(status_code=500, detail=f"JSON processing failed: {str(e)}")

class FileProcessorFactory:
    @staticmethod
    def create_processor(file_extension: str, ollama_client, settings: Settings) -> FileProcessor:
        processors = {
            'png': partial(ImageProcessor, model=settings.ollama_model_image),
            'jpg': partial(ImageProcessor, model=settings.ollama_model_image),
            'jpeg': partial(ImageProcessor, model=settings.ollama_model_image),
            'mp3': AudioProcessor,
            'wav': AudioProcessor,
            'pdf': partial(PDFProcessor, model=settings.ollama_model_text),
            'csv': partial(CSVProcessor, model=settings.ollama_model_text),
            'json': partial(JSONProcessor, model=settings.ollama_model_text)
        }
        processor_class = processors.get(file_extension.lower())
        if not processor_class:
            raise HTTPException(status_code=400, detail="Unsupported file type")
        return processor_class(ollama_client=ollama_client)