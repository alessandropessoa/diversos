from decouple import config, Csv

class Settings:
    ollama_model_text: str = config('OLLAMA_MODEL_TEXT', default='llama3.1')
    ollama_model_image: str = config('OLLAMA_MODEL_IMAGE', default='llava')
    allowed_extensions: list = config('ALLOWED_EXTENSIONS', cast=Csv(), default=['png', 'jpg', 'jpeg', 'mp3', 'wav', 'pdf', 'csv', 'json'])
    log_level: str = config('LOG_LEVEL', default='INFO')