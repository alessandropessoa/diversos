#!/usr/bin/env python3

import cgi
import os
import cgitb

# Habilitar depuração de erros CGI
cgitb.enable()

# Diretório onde os arquivos serão salvos
UPLOAD_DIR = "uploads"
MAX_FILE_SIZE = 1 * 1024 * 1024 * 1024  # 1GB em bytes

# Criar diretório de upload se não existir
if not os.path.exists(UPLOAD_DIR):
    os.makedirs(UPLOAD_DIR)

def process_upload():
    # Criar objeto de formulário
    form = cgi.FieldStorage()
    
    # Verificar se existe um arquivo no formulário
    if 'file' not in form:
        return "Nenhum arquivo selecionado"
    
    fileitem = form['file']
    
    # Verificar se o arquivo tem nome
    if not fileitem.filename:
        return "Nenhum arquivo selecionado"
    
    # Obter nome do arquivo
    filename = os.path.basename(fileitem.filename)
    filepath = os.path.join(UPLOAD_DIR, filename)
    
    # Verificar tamanho do arquivo
    if len(fileitem.file.read()) > MAX_FILE_SIZE:
        return "Arquivo excede o limite de 1GB"
    
    # Voltar ao início do arquivo
    fileitem.file.seek(0)
    
    # Salvar o arquivo
    with open(filepath, 'wb') as f:
        while True:
            chunk = fileitem.file.read(8192)
            if not chunk:
                break
            f.write(chunk)
    
    return f"Arquivo {filename} enviado com sucesso!"

# Gerar resposta HTML
print("Content-Type: text/html; charset=utf-8\n")
print("""
<html>
<head>
    <title>Upload de Arquivo</title>
</head>
<body>
    <h1>Upload de Arquivo</h1>
    <form enctype="multipart/form-data" method="post">
        <input type="file" name="file">
        <input type="submit" value="Enviar">
    </form>
    <p>{}</p>
</body>
</html>
""".format(process_upload()))
